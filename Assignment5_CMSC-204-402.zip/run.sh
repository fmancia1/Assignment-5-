#!/bin/sh

CP="junit.jar:hamcrest-core.jar:."

# Compiling

javac TreeNode.java MorseCodeTree.java MorseCodeConverter.java MorseCodeMain.java MorseCodeDriverFX.java MorseCodeConverterTest.java MorseCodeConverter_GFA_Test.java LinkedConverterTreeInterface.java

# MorseCodeConverterTest.java
#MorseCodeConverter.java
 # IOException.java
# javac -cp $CP SortedDoubleLinkedListTest.java SortedDoubleLinkedList.java SortedDoubleLinkedList_GFA_Test.java 
# javac -cp $CP DoubleLinkedListDriver.java 

# Running
# java -cp $CP org.junit.runner.JUnitCore BasicDoubleLinkedListTest
# java -cp $CP org.junit.runner.JUnitCore SortedDoubleLinkedListTest
javac -cp junit-4.13.2.jar:hamcrest-core-1.3.jar:. MorseCodeConverter_GFA_Test.java MorseCodeConverter.java MorseCodeConverterTest.java 
java -cp junit-4.13.2.jar:hamcrest-core-1.3.jar:. org.junit.runner.JUnitCore MorseCodeConverterTest
# timeout /t -1