/**
* This is the ModeCodeConverter class
*
*
* @author Fatima Mancia
*
*/
import java.io.FileReader;
import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.Scanner; 
import java.io.FileNotFoundException;
import java.io.File;
public class MorseCodeConverter {
  static MorseCodeTree codeTree;
  public MorseCodeConverter() {
  codeTree = new MorseCodeTree();
  }
   /**
	 * printTree it prints the words.
	 * @return the letter asked.
	 *
	 */
  public static String printTree() {
    String s = " ";
    ArrayList<String> list = codeTree.toArrayList();
    for (int i = 0; i < list.size(); i++) {
         s += list.get(i);
    }
    return s;
  }
   /**
	 * converterToEnglish translates the word.
	 * @return the word in English.
	 *
	 */
  public static String convertToEnglish(String code) {
    String s = "";
    String w = "";
    String l = "";
    for (int i = 0; i < code.length(); i++) {
      if (code.charAt(i) == ' ') {
        w += l;
        l = "";
      }
      else if (code.charAt(i) == '/') {
        s += " " + w;
        w = "";
      }
      else {
        l +=  codeTree.fetch(code);
      }
    }
    return s;
  }
   /**
	 * convertToEnglish reads the file.
	 *  @param founds the file.
	 *
	 */
  public static String convertToEnglish(File codeFile) throws FileNotFoundException {
    FileReader fr = new FileReader(codeFile);
    BufferedReader lineReader = new BufferedReader(fr);
    String line = null;
    while (true)
    try {
      line = lineReader.readLine();
      return convertToEnglish(line);
    }
    catch (Exception e) {
    }
  }
}