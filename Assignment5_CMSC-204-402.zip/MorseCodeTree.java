/**
* This is the MorseCodeTree class
*
*
* @author Fatima Mancia
*
*/
import java.util.ArrayList;
public class MorseCodeTree implements LinkedConverterTreeInterface<String> {
  TreeNode<String> root;
  TreeNode<String> left;
  TreeNode<String> right;
  public MorseCodeTree() {
    buildTree();
  }
  /**
   * TreeNode<String> gets the root.
   * 
   * @return root.
   *
   */
  public TreeNode<String> getRoot() {
    return root;
  }
  /**
   * setRoot creates new node.
   * @param creates a newNode.
   * 
   *
   */
  public void setRoot(TreeNode<String> newNode) {
    root = newNode;
  }
  /**
   * MorseCodeTree adds new Node.
   * @param code and letter.
   * @return everything.
   *
   */
  public MorseCodeTree insert(String code, String letter) {
    addNode(root, code, letter);
    return this;
  }
  /**
   * addNode adds new node.
   * @param root, code and letter.
   * 
   *
   */
  public void addNode(TreeNode<String> root, String code, String letter) {
    Character c = code.charAt(0);
    TreeNode<String> child;
    if (c == '.')
      child = root.left;
    else
      child = root.right;
    if (child == null) {
      child = new TreeNode<String>(" ");
    }
    if (code.length() > 1) {
      addNode(child, code.substring(1), letter);
    }
    else {
      child.setData(letter);
    }
  }
  /**
   * fetch gets the node.
   * @param code.
   * @return gets the node.
   *
   */
  public String fetch(String code) {
    return fetchNode(root, code);
  }
  /**
   * fetchNode gets the node.
   * @param root, code.
   * @return the next node.
   *
   */
  public String fetchNode(TreeNode<String> root, String code) {
    if (code.length() == 1)
      return root.getData();
    Character c = code.charAt(0);
    TreeNode<String> child;
    if (c == '.') {
      child = root.left;
    }
    else {
      child = root.right;
    }
    return fetchNode(child, code.substring(1));
  }
  /**
   * delete it is not supported.
   * @param data.
   * @return Exception.
   *
   */
  public MorseCodeTree delete(String data) throws UnsupportedOperationException {
    throw new UnsupportedOperationException("This operation is not supported in the MorseCodeTree");
  }
  /**
   * update it is not supported. 
   *@return Exception.
   *
   */
  public MorseCodeTree update() throws UnsupportedOperationException {
    throw new UnsupportedOperationException("This operation is not supported in the MorseCodeTree");
  }
  /**
   * buildTree creates the binary tree.
   * 
   * 
   *
   */
  public void buildTree() {
    insert(".-", "a");
    insert("-...", "b");
    insert("-.-.", "c");
    insert("-..", "d");
    insert(".", "e");
    insert("..-.", "f");
    insert("--.", "g");
    insert("....", "h");
    insert("..", "i");
    insert(".---", "j");
    insert("-.-", "k");
    insert(".-..", "l");
    insert("--", "m");
    insert("-.", "n");
    insert("---", "o");
    insert(".--.", "p");
    insert("--.-", "q");
    insert(".-.", "r");
    insert("...", "s");
    insert("-", "t");
    insert("..-", "u");
    insert("...-", "v");
    insert(".--", "w");
    insert("-..-", "x");
    insert("-.--", "y");
    insert("--..", "z");
  }
  /**
   * toArrayList creates ArrayList.
   * 
   * @return list.
   *
   */
  public ArrayList<String> toArrayList() {
    ArrayList<String> list = new ArrayList<String>();
    LNRoutputTraversal(root, list);
    return list;
  }
  /**
   * LNRoutputTraversal creates the list.
   * @param node, list.
   * 
   *
   */
public void LNRoutputTraversal(TreeNode<String> node, ArrayList<String> list) {
  if (node.left != null)
    LNRoutputTraversal(node.left, list);
  list.add(node.getData());
  if (node.right != null)
    LNRoutputTraversal(node.right, list);
  }
}