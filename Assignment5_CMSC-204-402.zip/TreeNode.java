/**
* This is the TreeNode<T> class
*
*
* @author Fatima Mancia
*
*/
public class TreeNode<T> {
  T data;
  TreeNode<T> left;
  TreeNode<T> right;
  TreeNode<T> parent;
  TreeNode(T dataNode) {
    data = dataNode;
    left = null;
    right = null;
    parent = null;
  }
  TreeNode(TreeNode<T> node) {
    left = node.left;
    right = node.right;
    parent = node.parent;
    data = node.data;
  }
  /**
   * getData gets the data.
   * @return data.
   *
   */
  public T getData() {
    return data;
  }
  /**
   * setData gets the new data.
   * @param newData.
   *
   */
  public void setData(T newData) {
    data = newData;
  }
}